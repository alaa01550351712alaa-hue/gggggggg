package com.example.yacinestylebackup;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/** Small Xtream Codes API client. Network calls must be made off the UI thread. */
public final class XtreamApi {
    public static final class Item {
        public final String name, url, id, extension;
        public Item(String n, String u, String i, String e) { name=n; url=u; id=i; extension=e; }
    }
    private final String host, user, pass;
    private final Context appContext;
    public XtreamApi(Context c) {
        appContext = c.getApplicationContext();
        SharedPreferences p=c.getSharedPreferences("iptv_server", Context.MODE_PRIVATE);
        host=normalize(p.getString("host", "")); user=p.getString("username", ""); pass=p.getString("password", "");
    }
    public boolean isConfigured(){ return !host.isEmpty() && !user.isEmpty() && !pass.isEmpty(); }
    public String host(){ return host; }
    private static String normalize(String s){ if(s==null)return ""; s=s.trim(); while(s.endsWith("/"))s=s.substring(0,s.length()-1); if(!s.isEmpty()&&!s.matches("(?i)^https?://.*"))s="http://"+s; return s; }
    private String apiUrl(String action){ return host+"/player_api.php?username="+Uri.encode(user)+"&password="+Uri.encode(pass)+(action==null?"":"&action="+Uri.encode(action)); }
    private String get(String url) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setConnectTimeout(12000); c.setReadTimeout(20000); c.setRequestMethod("GET"); c.setRequestProperty("Accept","application/json");
        try { int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); if(in==null)throw new Exception("HTTP "+code); StringBuilder b=new StringBuilder(); try(BufferedReader r=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)b.append(line);} if(code<200||code>=300)throw new Exception("HTTP "+code); return b.toString(); } finally { c.disconnect(); }
    }
    public boolean test() throws Exception { JSONObject j=new JSONObject(get(apiUrl(null))); JSONObject userInfo=j.optJSONObject("user_info"); return userInfo!=null && "Active".equalsIgnoreCase(userInfo.optString("status")); }
    private File cacheFile(String type) { return new File(appContext.getCacheDir(), "iptv_" + type + "_" + Integer.toHexString((host+"|"+user).hashCode()) + ".json"); }
    public ArrayList<Item> loadCached(String type) {
        ArrayList<Item> out = new ArrayList<>();
        try {
            File f = cacheFile(type); if (!f.isFile()) return out;
            byte[] bytes = new byte[(int) f.length()];
            try (FileInputStream in = new FileInputStream(f)) { int off=0,n; while(off<bytes.length && (n=in.read(bytes,off,bytes.length-off))>0) off+=n; }
            JSONArray a = new JSONArray(new String(bytes, StandardCharsets.UTF_8));
            for(int i=0;i<a.length();i++){ JSONObject o=a.optJSONObject(i); if(o!=null) out.add(new Item(o.optString("name"),o.optString("url"),o.optString("id"),o.optString("extension"))); }
        } catch(Exception ignored) { }
        return out;
    }
    private void saveCache(String type, ArrayList<Item> items) {
        try {
            JSONArray a=new JSONArray(); for(Item item:items){ JSONObject o=new JSONObject(); o.put("name",item.name); o.put("url",item.url); o.put("id",item.id); o.put("extension",item.extension); a.put(o); }
            try(FileOutputStream out=new FileOutputStream(cacheFile(type))){out.write(a.toString().getBytes(StandardCharsets.UTF_8));}
        } catch(Exception ignored) { }
    }
    public ArrayList<Item> load(String type) throws Exception {
        String action="live".equals(type)?"get_live_streams":"movies".equals(type)?"get_vod_streams":"get_series";
        JSONArray a=new JSONArray(get(apiUrl(action))); ArrayList<Item> out=new ArrayList<>();
        for(int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if(o==null)continue; String id=o.optString("stream_id",o.optString("series_id", "")); String name=o.optString("name", "بدون اسم"); String ext=o.optString("container_extension", "ts"); String url="";
            if("live".equals(type))url=host+"/live/"+Uri.encode(user)+"/"+Uri.encode(pass)+"/"+id+"."+ext;
            else if("movies".equals(type))url=host+"/movie/"+Uri.encode(user)+"/"+Uri.encode(pass)+"/"+id+"."+ext;
            out.add(new Item(name,url,id,ext));
        } saveCache(type,out); return out;
    }
    public ArrayList<Item> loadEpisodes(String seriesId) throws Exception {
        JSONObject root=new JSONObject(get(apiUrl("get_series_info")+"&series_id="+Uri.encode(seriesId))); JSONObject eps=root.optJSONObject("episodes"); ArrayList<Item> out=new ArrayList<>(); if(eps==null)return out;
        java.util.Iterator<String> keys=eps.keys(); while(keys.hasNext()){String season=keys.next(); JSONArray a=eps.optJSONArray(season); if(a==null)continue; for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String id=o.optString("id","");String ext=o.optString("container_extension","mp4");String name=o.optString("title", "حلقة "+(i+1));out.add(new Item(name,host+"/series/"+Uri.encode(user)+"/"+Uri.encode(pass)+"/"+id+"."+ext,id,ext));}}
        return out;
    }
}
